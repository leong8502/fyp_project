import pygame
from pygame.locals import *
import random

pygame.init()

#time and speed control the movement of ground and others
clock = pygame.time.Clock()
fps = 60

#size of the screen
screen_width = 864
screen_height = 936

screen = pygame.display.set_mode((screen_width,screen_height))
pygame.display.set_caption('Floppy Chicken') #caption name on the top

#define font
font = pygame.font.SysFont('Bauhaus 93', 60)
#define colours
white = (255, 255, 255)

#define game variables
Ground_scroll = 0
scroll_speed = 4  #4 pixels
flying = False
game_over = False
pipe_gap = 150
pipe_frequency = 1500 #how often the pipes are created in miliseconds
last_pipe = pygame.time.get_ticks() - pipe_frequency
score = 0
pass_pipe = False

#load images
BG = pygame.image.load('BG.png')
Ground_img = pygame.image.load('Ground.png')
button_img = pygame.image.load('restart.png')

def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))


def reset_game():
    pipe_group.empty()
    Floppy.rect.x = 100
    Floppy.rect.y = int(screen_height / 2)
    score = 0
    return score

class Chicken(pygame.sprite.Sprite):
    def __init__(self, x, y):               #self is the chicken, x and y is the place of the chicken
        pygame.sprite.Sprite.__init__(self)
        self.images = []   
        self.index = 0
        self.counter = 0 #control speed of animation run
        for num in range(1,4): #range of images, 1,2,3 only 4 wouldn't taken
            img = pygame.image.load(f'Chicken{num}.png')  #f is formatting strings, num is the for different pic with different num
            self.images.append(img)
        self.image = self.images[self.index] 
        self.rect = self.image.get_rect()
        self.rect.center = [x,y]
        self.vel = 0 
        self.clicked = False

    def update(self):

        if flying == True:
            #gravity
            self.vel += 0.7
            if self.vel > 8:
                self.vel = 8
            if self.rect.bottom < 768:
                self.rect.y += int(self.vel)

        if game_over == False:
            #jump 
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                self.vel = -10
            if pygame.mouse.get_pressed()[0] == 0:
                self.clicked= False

            #handle the animation
            self.counter += 1
            flap_cooldown = 5

            if self.counter > flap_cooldown:
                self.counter = 0
                self.index += 1
                self.index = self.index % len(self.images)

                self.image = self.images[self.index] 

            #chicken rotating animation
            self.image = pygame.transform.rotate(self.images[self.index], self.vel * -2)
        else: 
            self.image = pygame.transform.rotate(self.images[self.index], -90)




class Pipe(pygame.sprite.Sprite): #adding pipe
    def __init__(self, x, y, position):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('pipe.png')
        self.rect = self.image.get_rect()
        #position 1 is from the top , -1 is from the bottom
        if position == 1:
            self.image = pygame.transform.flip(self.image, False, True)
            self.rect.bottomleft = [x, y - int(pipe_gap / 2)]
        if position == -1:
            self.rect.topleft = [x, y + int(pipe_gap / 2)]

    def update(self):
        self.rect.x -= scroll_speed
        if self.rect.right < 0:
            self.kill()

class Button():
    def __init__(self, x, y, image):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

    def draw(self):

        action = False

        #get mouse position
        pos = pygame.mouse.get_pos()

        #check if mouse is over the button
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1:
                action = True

        #draw button
        screen.blit(self.image, (self.rect.x, self.rect.y))

        return action         

chicken_group = pygame.sprite.Group()  #flying movement group
pipe_group = pygame.sprite.Group() #pipe group

Floppy = Chicken(100, int(screen_height / 2))

chicken_group.add(Floppy)

#create restart button instance
button = Button(screen_width // 2 - 50, screen_height // 2 - 100, button_img)


run = True
while run:

    clock.tick(fps)

    #backgroud display
    screen.blit(BG,(0,0))

    chicken_group.draw(screen)
    chicken_group.update()
    pipe_group.draw(screen)
    

    #draw the ground
    screen.blit(Ground_img,(Ground_scroll,768))

    #check the score
    if len(pipe_group) > 0:
        if chicken_group.sprites()[0].rect.left > pipe_group.sprites()[0].rect.left\
            and chicken_group.sprites()[0].rect.right < pipe_group.sprites()[0].rect.right\
            and pass_pipe == False:
            pass_pipe = True
        if pass_pipe == True:
            if chicken_group.sprites()[0].rect.left > pipe_group.sprites()[0].rect.right:
                score += 1
                pass_pipe = False

    draw_text(str(score), font, white, int(screen_width / 2), 20)

    #pipe collision
    if pygame.sprite.groupcollide(chicken_group, pipe_group, False, False) or Floppy.rect.top < 0:
        game_over = True

    #check if bird has hit the ground
    if Floppy.rect.bottom > 768:
        game_over = True
        flying = False
    

    if game_over == False and flying == True:

        #generating new pipes
        time_now = pygame.time.get_ticks()
        if time_now - last_pipe > pipe_frequency:
            pipe_height = random.randint(-200, 200)
            btm_pipe = Pipe(screen_width, int(screen_height / 2) + pipe_height, -1) #adding the pipe to game
            top_pipe = Pipe(screen_width, int(screen_height / 2) + pipe_height, 1)
            pipe_group.add(btm_pipe) 
            pipe_group.add(top_pipe)      
            last_pipe = time_now      


    #ground display and scroll the ground
        Ground_scroll -= scroll_speed   #it will become negative
        if abs(Ground_scroll) > 35:     #abs for changing the negative number to positive, 35 is the pixels length of the ground
            Ground_scroll = 0           #when over the length,it return to 0,it will be like loop to make the ground moving vision
        pipe_group.update()
    
     #check for game over and reset
    if game_over == True:
        if button.draw() == True:
            game_over = False
            score = reset_game()
            
    #Quit button
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN and flying == False and game_over == False:
            flying = True

    pygame.display.update()  #for update the picture display, like background and ground

pygame.quit()